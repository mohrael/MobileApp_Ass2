package com.example.mobile_assignment2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
